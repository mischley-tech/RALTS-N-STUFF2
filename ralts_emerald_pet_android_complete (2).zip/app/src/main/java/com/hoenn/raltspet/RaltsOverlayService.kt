package com.hoenn.raltspet

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class RaltsOverlayService : Service() {

    companion object {
        const val ACTION_STOP_OVERLAY = "com.hoenn.raltspet.ACTION_STOP_OVERLAY"
        private const val CHANNEL_ID = "ralts_walker_fg_channel"
        private const val NOTIF_ID = 2801

        @Volatile
        var isRunning: Boolean = false
    }

    private var windowManager: WindowManager? = null
    private var walkerView: RaltsWalkerView? = null
    private lateinit var overlayParams: WindowManager.LayoutParams
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_OVERLAY) {
            stopSelf()
            return START_NOT_STICKY
        }
        promoteToForeground()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        promoteToForeground()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        val density = dm.density
        val boxW = (132 * density).toInt()
        val boxH = (152 * density).toInt()

        overlayParams = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dm.widthPixels - boxW) / 2
            y = (dm.heightPixels * 0.45f).toInt()
        }

        walkerView = RaltsWalkerView(this, overlayParams.x.toFloat(), overlayParams.y.toFloat())
        try {
            windowManager?.addView(walkerView, overlayParams)
        } catch (_: Exception) {
            stopSelf()
            return
        }
        RaltsWidgetProvider.updateAllWidgets(this)
    }

    private fun promoteToForeground() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ralts Screen Walker",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)

            val stopIntent = Intent(this, RaltsOverlayService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            val stopPending = PendingIntent.getService(
                this, 99, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notif = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Ralts is walking across your screen")
                .setContentText("Tap Ralts to pet, double-tap to feed, or tap here to recall.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(stopPending)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, notif)
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        val viewToRemove = walkerView
        if (viewToRemove != null) {
            try {
                windowManager?.removeView(viewToRemove)
            } catch (_: Exception) {}
        }
        walkerView = null
        RaltsWidgetProvider.updateAllWidgets(this)
        super.onDestroy()
    }

    inner class RaltsWalkerView(
        context: Context,
        initialX: Float,
        initialY: Float
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val spritePaint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
        private val bubbleBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E60F291E")
            style = Paint.Style.FILL
        }
        private val bubbleBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#52B788")
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        private val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F472B6")
            textSize = 34f
            textAlign = Paint.Align.CENTER
        }

        // True float coordinates so Ralts roams smoothly in 2D across the entire screen!
        private var posX = initialX
        private var posY = initialY
        private var vx = 4.2f
        private var vy = 2.4f
        private var facingRight = true
        private var isPaused = false
        private var pauseTicks = 0
        private var tickCount = 0
        private var petHappyTicks = 0
        private var bubbleText = "Ralts! 💚"

        private var isDragging = false
        private var downRawX = 0f
        private var downRawY = 0f
        private var startPosX = 0f
        private var startPosY = 0f
        private var downTimeMs = 0L
        private var lastTapMs = 0L

        private val loopRunnable = object : Runnable {
            override fun run() {
                if (!isRunning) return
                stepAnimation()
                invalidate()
                mainHandler.postDelayed(this, 33L) // ~30 FPS continuous animation across all apps
            }
        }

        init {
            mainHandler.post(loopRunnable)
        }

        private fun pickNewWanderVelocity() {
            val speedX = Random.nextInt(30, 58) / 10f
            val speedY = Random.nextInt(18, 42) / 10f
            vx = if (Random.nextBoolean()) speedX else -speedX
            vy = if (Random.nextBoolean()) speedY else -speedY
            facingRight = vx >= 0f
        }

        private fun stepAnimation() {
            tickCount++
            if (petHappyTicks > 0) {
                petHappyTicks--
            }

            if (isDragging) return

            if (isPaused) {
                pauseTicks--
                if (pauseTicks <= 0) {
                    isPaused = false
                    pickNewWanderVelocity()
                }
                return
            } else if (petHappyTicks == 0 && Random.nextInt(160) == 0) {
                isPaused = true
                pauseTicks = Random.nextInt(25, 55)
                return
            } else if (tickCount % 110 == 0) {
                // Slightly vary direction as Ralts explores the screen
                vy = (Random.nextInt(-38, 39) / 10f)
            }

            val dm = resources.displayMetrics
            val viewW = if (width > 0) width else (132 * dm.density).toInt()
            val viewH = if (height > 0) height else (152 * dm.density).toInt()
            val maxX = (dm.widthPixels - viewW).toFloat().coerceAtLeast(10f)
            val minY = dm.heightPixels * 0.05f
            val maxY = (dm.heightPixels - viewH - (48 * dm.density)).coerceAtLeast(100f)

            posX += vx
            posY += vy

            if (posX <= 0f) {
                posX = 0f
                vx = abs(vx)
                facingRight = true
            } else if (posX >= maxX) {
                posX = maxX
                vx = -abs(vx)
                facingRight = false
            }

            if (posY <= minY) {
                posY = minY
                vy = abs(vy)
            } else if (posY >= maxY) {
                posY = maxY
                vy = -abs(vy)
            }

            overlayParams.x = posX.toInt()
            overlayParams.y = posY.toInt()
            try {
                windowManager?.updateViewLayout(this, overlayParams)
            } catch (_: Exception) {}
        }

        private fun triggerPetAction() {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val happy = min(100, prefs.getInt("happiness", 85) + 12)
            val rawSpecies = prefs.getString("species", "RALTS") ?: "RALTS"
            val rawNick = prefs.getString("nickname", "") ?: ""
            val nickname = if (rawNick.trim().isEmpty()) rawSpecies else rawNick

            prefs.edit()
                .putInt("happiness", happy)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", true)
                .apply()

            petHappyTicks = 45
            val phrases = arrayOf(
                "$nickname loves it! 💚",
                "Happy: $happy%! ✨",
                "Ralts-ralts! 💖",
                "So happy! 🌿"
            )
            bubbleText = phrases[Random.nextInt(phrases.size)]
            RaltsWidgetProvider.updateAllWidgets(context)
        }

        private fun triggerFeedAction() {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val hunger = min(100, prefs.getInt("hunger", 80) + 22)
            var level = prefs.getInt("level", 5) + 1
            var stage = prefs.getInt("stage", 0)
            if (stage == 0 && level >= 20) stage = 1
            if (stage == 1 && level >= 30) stage = 2
            val species = when (stage) {
                1 -> "KIRLIA"
                2 -> "GARDEVOIR"
                else -> "RALTS"
            }

            prefs.edit()
                .putInt("hunger", hunger)
                .putInt("level", level)
                .putInt("stage", stage)
                .putString("species", species)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", true)
                .apply()

            petHappyTicks = 50
            bubbleText = "🍇 Ate Berry! Lv.$level ($hunger%)"
            RaltsWidgetProvider.updateAllWidgets(context)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val stage = prefs.getInt("stage", 0)
            val isShiny = prefs.getBoolean("isShiny", false)

            val walkFrame = if (isDragging || petHappyTicks > 0) {
                (tickCount / 3) % 2
            } else if (!isPaused) {
                (tickCount / 5) % 2
            } else {
                0
            }

            val baseBmp = RaltsWidgetProvider.renderGen3SpriteBitmap(stage, isShiny, walkFrame)
            val finalBmp: Bitmap = if (facingRight) {
                val m = Matrix().apply { preScale(-1f, 1f) }
                Bitmap.createBitmap(baseBmp, 0, 0, baseBmp.width, baseBmp.height, m, false)
            } else {
                baseBmp
            }

            val bounceY = when {
                petHappyTicks > 0 -> -abs(sin(tickCount * 0.45f) * 22f)
                isDragging -> sin(tickCount * 0.5f) * 8f
                !isPaused -> -abs(sin(tickCount * 0.38f) * 9f)
                else -> 0f
            }

            paint.color = Color.parseColor("#55000000")
            val shadowOval = RectF(width * 0.25f, height - 24f, width * 0.75f, height - 10f)
            canvas.drawOval(shadowOval, paint)

            val spriteSize = (width * 0.74f).toInt()
            val left = (width - spriteSize) / 2f
            val top = height - spriteSize - 16f + bounceY
            val dstRect = RectF(left, top, left + spriteSize, top + spriteSize)
            canvas.drawBitmap(finalBmp, null, dstRect, spritePaint)

            if (petHappyTicks > 0) {
                val floatOffset = (45 - petHappyTicks) * 1.3f
                canvas.drawText("💚", width * 0.22f, top + 14f - floatOffset, heartPaint)
                canvas.drawText("💖", width * 0.78f, top + 22f - floatOffset * 0.8f, heartPaint)
                canvas.drawText("✨", width * 0.50f, top - 2f - floatOffset * 1.1f, heartPaint)

                val bubbleRect = RectF(4f, 6f, width - 4f, 46f)
                canvas.drawRoundRect(bubbleRect, 16f, 16f, bubbleBgPaint)
                canvas.drawRoundRect(bubbleRect, 16f, 16f, bubbleBorderPaint)
                canvas.drawText(bubbleText, width / 2f, 33f, textPaint)
            }
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startPosX = posX
                    startPosY = posY
                    downTimeMs = System.currentTimeMillis()
                    isDragging = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (abs(dx) > 18f || abs(dy) > 18f) {
                        isDragging = true
                        posX = startPosX + dx
                        posY = startPosY + dy
                        overlayParams.x = posX.toInt()
                        overlayParams.y = posY.toInt()
                        try {
                            windowManager?.updateViewLayout(this, overlayParams)
                        } catch (_: Exception) {}
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val now = System.currentTimeMillis()
                    val heldDuration = now - downTimeMs
                    if (!isDragging) {
                        if (heldDuration >= 850L) {
                            // Hold for ~1 second to send Ralts back to the widget
                            Toast.makeText(
                                context,
                                "🏠 Ralts returned to your Home Screen Widget!",
                                Toast.LENGTH_SHORT
                            ).show()
                            this@RaltsOverlayService.stopSelf()
                        } else if (now - lastTapMs < 350L) {
                            // Double-tap Ralts to feed an Oran Berry right on screen!
                            triggerFeedAction()
                        } else {
                            // Single-tap Ralts to pet!
                            triggerPetAction()
                        }
                        lastTapMs = now
                    }
                    isDragging = false
                    return true
                }
            }
            return super.onTouchEvent(event)
        }
    }
}
