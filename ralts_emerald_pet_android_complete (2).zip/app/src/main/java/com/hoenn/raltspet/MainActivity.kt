package com.hoenn.raltspet

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        const val ACTION_START_SCREEN_WALKER = "com.hoenn.raltspet.ACTION_START_SCREEN_WALKER"
    }

    private lateinit var webView: WebView
    private var waitingForOverlayPermission = false

    inner class AndroidWidgetBridge(private val context: Context) {
        @JavascriptInterface
        fun updateWidgetData(
            nickname: String,
            species: String,
            level: Int,
            stage: Int,
            hunger: Int,
            happiness: Int,
            isShiny: Boolean
        ) {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("nickname", nickname)
                .putString("species", species)
                .putInt("level", level)
                .putInt("stage", stage)
                .putInt("hunger", hunger)
                .putInt("happiness", happiness)
                .putBoolean("isShiny", isShiny)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", false)
                .apply()
            RaltsWidgetProvider.updateAllWidgets(context)
        }

        @JavascriptInterface
        fun toggleScreenWalker(): Boolean {
            val nextState = !RaltsOverlayService.isRunning
            runOnUiThread {
                if (RaltsOverlayService.isRunning) {
                    stopService(Intent(this@MainActivity, RaltsOverlayService::class.java))
                    RaltsWidgetProvider.updateAllWidgets(this@MainActivity)
                } else {
                    launchOverlayOrAskPermission(minimizeToHome = true)
                }
            }
            return nextState
        }

        @JavascriptInterface
        fun isScreenWalkerActive(): Boolean {
            return RaltsOverlayService.isRunning
        }
    }

    private fun startOverlayServiceNow(minimizeToHome: Boolean) {
        val svcIntent = Intent(this, RaltsOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svcIntent)
        } else {
            startService(svcIntent)
        }
        RaltsWidgetProvider.updateAllWidgets(this)
        Toast.makeText(
            this,
            "💚 Ralts is now walking across your screen! Tap to pet, double-tap to feed, drag to move, or hold 1s to recall.",
            Toast.LENGTH_LONG
        ).show()
        if (minimizeToHome) {
            moveTaskToBack(true)
        }
    }

    fun launchOverlayOrAskPermission(minimizeToHome: Boolean) {
        if (Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false
            startOverlayServiceNow(minimizeToHome)
        } else {
            waitingForOverlayPermission = true
            Toast.makeText(
                this,
                "Step 1: Turn ON 'Allow display over other apps' for Ralts Emerald Pet, then press Back!",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false

        webView.addJavascriptInterface(AndroidWidgetBridge(this), "AndroidWidgetBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                syncFromWidgetIfNeeded()
            }
        }
        webView.loadUrl("file:///android_asset/index.html")

        if (intent?.action == ACTION_START_SCREEN_WALKER) {
            if (RaltsOverlayService.isRunning) {
                stopService(Intent(this, RaltsOverlayService::class.java))
                RaltsWidgetProvider.updateAllWidgets(this)
                Toast.makeText(
                    this,
                    "🏠 Ralts returned to your Home Screen Widget!",
                    Toast.LENGTH_SHORT
                ).show()
                moveTaskToBack(true)
            } else {
                launchOverlayOrAskPermission(minimizeToHome = true)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false
            startOverlayServiceNow(minimizeToHome = true)
        }
        RaltsWidgetProvider.applyElapsedDecay(this)
        syncFromWidgetIfNeeded()
    }

    private fun syncFromWidgetIfNeeded() {
        val prefs = getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("widget_dirty", false)) {
            val level = prefs.getInt("level", 5)
            val stage = prefs.getInt("stage", 0)
            val hunger = prefs.getInt("hunger", 84)
            val happiness = prefs.getInt("happiness", 88)
            prefs.edit().putBoolean("widget_dirty", false).apply()
            webView.evaluateJavascript(
                "if(window.receiveWidgetSync){window.receiveWidgetSync($level,$stage,$hunger,$happiness);}",
                null
            )
        }
    }
}
